<?php
//MAIN CONF
define('SITENAME','Sarlaft');
define('PASSWORD_APP','sarlaft2015');
define('APPLICATION','Sarlaft');
define('INSTANCE','10.158.117.130');
define('DB','dbsarlaft');
define('DB_USER','usr_sarlaft');
define('DB_PASS','edd6c7033f2381d0fe4e8392233d30fe');
//profile path
define('DIRPATH', $_SERVER['DOCUMENT_ROOT']); 
define('AVATARPATH','/archivos/multimedia/profiles/pics/');
define('PATH_UPLOAD_REGISTROS', DIRPATH.AVATARPATH);
define('ARCHIVOSPATH','/archivos/');
define('PATH_UPLOAD_ARCHIVOS', DIRPATH.ARCHIVOSPATH);
//COPYRIGHT
define('COPYRIGHT', 'UNE TELECOMUNICACIONES');
//massdataupload
define('MASSUPLOADPATH','/archivos/tmp/massdataupload/');
define('UPLOADFILEPATH', DIRPATH.'MASSUPLOADPATH');
define('TABLE_PREFIX','tbl_');
