$('#bell').live('click',function(){
    $.post("?r=FrontEnd", {notyRefresh: "true"}, function(data) { 
			 location.reload();
		});
});