<br><br><br>
<div class="form">
    <?php
        $this->widget('bootstrap.widgets.TbAlert', array(
                        'block' => true,
                        'fade' => true,
                        'closeText' => '&times;',
                        'events' => array(),
                        'htmlOptions' => array(),
                        'userComponentId' => 'user'
                        )
                    );    
    ?>
</div>
<br><br><br><br><br>
<br><br><br><br><br><br><br><br>
