<?php
$language['button_export'] 				= 'Exportar';
$language['button_check_all'] 			= 'Marcar Todo';
$language['button_un_check_all'] 		= 'Desmarcar Todo';
$language['button_close'] 				= 'Cerrar';
$language['button_reload'] 				= 'Recargar consulta';
$language['button_remove_order'] 		= 'Quitar Ordenación';
$language['button_remove_filters'] 		= 'Quitar Filtros';
$language['button_order_grid'] 			= 'Ordenar Grid';
$language['button_hide_show_columns'] 	= 'Mostrar/Ocultar Columnas';

$language['text_orientation'] 			= 'Orientación';
$language['textExportWindow'] 			= 'Seleccione los campos a exportar';
$language['textInputSearch'] 			= 'Palabra Clave';
$language['text_yes'] 					= 'Si';
$language['text_no'] 					= 'No';
$language['text_no_registers'] 			= 'No. Reg.';